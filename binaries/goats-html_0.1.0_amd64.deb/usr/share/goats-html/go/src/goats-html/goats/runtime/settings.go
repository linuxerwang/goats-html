package runtime

type GoatsSettings struct {
	DevServerPort int    // Only used for dev mode
	PkgRoot       string // Only used for dev mode
	TemplateDir   string // Only used for dev mode
	OutputDir     string // Only used for dev mode
}
